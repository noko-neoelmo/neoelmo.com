import Navigation from "@/components/navigation"
import Footer from "@/components/footer"

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <h1 className="text-4xl font-bold mb-8 text-gray-900 dark:text-white">
            プライバシーポリシー
          </h1>
          
          <div className="prose prose-lg max-w-none dark:prose-invert">
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              株式会社ネオエルモ（以下「当社」といいます。）は、当社の提供するサービスをご利用いただくお客様の個人情報の取扱いについて、以下のとおりプライバシーポリシー（以下「本ポリシー」といいます。）を定めます。
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">1. 個人情報の定義</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              本ポリシーにおいて、個人情報とは、個人情報保護法にいう「個人情報」を指すものとし、生存する個人に関する情報であって、当該情報に含まれる氏名、生年月日、住所、電話番号、連絡先その他の記述等により特定の個人を識別できる情報を指します。
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">2. 個人情報の収集方法</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              当社は、以下の場合に個人情報を収集することがあります：
            </p>
            <ul className="list-disc pl-6 text-gray-600 dark:text-gray-300 mb-4">
              <li>お客様がお問い合わせフォームから情報を入力される場合</li>
              <li>当社のサービスにお申し込みいただく場合</li>
              <li>当社とのお取引の過程で情報をご提供いただく場合</li>
              <li>アンケートや各種調査にご回答いただく場合</li>
              <li>当社のウェブサイトやサービスをご利用いただく場合</li>
            </ul>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">3. 個人情報の利用目的</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              当社は、収集した個人情報を以下の目的で利用いたします：
            </p>
            <ul className="list-disc pl-6 text-gray-600 dark:text-gray-300 mb-4">
              <li>お客様からのお問い合わせへの対応</li>
              <li>当社サービスの提供、維持、改善</li>
              <li>契約の締結、履行、アフターサービスの提供</li>
              <li>料金の請求及び決済処理</li>
              <li>新サービスや重要な変更についてのご案内</li>
              <li>アンケートの実施やマーケティング調査</li>
              <li>法令に基づく対応</li>
            </ul>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">4. 個人情報の第三者提供</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              当社は、以下の場合を除き、お客様の同意なく個人情報を第三者に提供することはありません：
            </p>
            <ul className="list-disc pl-6 text-gray-600 dark:text-gray-300 mb-4">
              <li>法令に基づく場合</li>
              <li>人の生命、身体又は財産の保護のために必要がある場合</li>
              <li>公衆衛生の向上又は児童の健全な育成の推進のために特に必要がある場合</li>
              <li>国の機関等が法令の定める事務を遂行することに対して協力する必要がある場合</li>
              <li>業務委託先に個人情報の取扱いを委託する場合</li>
            </ul>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">5. 個人情報の管理</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              当社は、個人情報の正確性及び安全性確保のため、セキュリティに万全の対策を講じています。また、当社の従業員に対して個人情報保護に関する教育を実施し、個人情報の適切な管理を徹底しています。
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">6. 個人情報の開示、訂正等について</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              お客様ご本人から個人情報の開示、訂正、削除等のお申し出があった場合には、遅滞なく対応いたします。これらのお申し出は、以下の連絡先までお願いいたします。
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">7. Cookieについて</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              当社のウェブサイトでは、お客様により良いサービスを提供するため、Cookieを使用することがあります。Cookieの使用を希望されない場合は、ブラウザの設定によりCookieの機能を無効にすることができます。
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">8. プライバシーポリシーの変更</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              当社は、必要に応じて本ポリシーを変更することがあります。変更後のプライバシーポリシーは、当社ウェブサイトに掲載した時点から効力を生じるものとします。
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900 dark:text-white">9. お問い合わせ先</h2>
            <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
              <p className="text-gray-600 dark:text-gray-300 mb-2">
                個人情報の取扱いに関するお問い合わせは、以下までご連絡ください。
              </p>
              <p className="text-gray-900 dark:text-white font-semibold">
                株式会社ネオエルモ<br />
                所在地：東京都練馬区<br />
                メールアドレス：info@neoelmo.com
              </p>
            </div>

            <p className="text-gray-500 dark:text-gray-400 text-sm mt-8">
              制定日：2025年3月3日<br />
              最終更新日：2025年3月3日
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}