import Navigation from "@/components/navigation"
import Hero from "@/components/hero"
import DnaSection from "@/components/dna-section"
import AboutSection from "@/components/about-section"
import ServicesSection from "@/components/services-section"
import AchievementsSection from "@/components/achievements-section"
import CompanyInfoSection from "@/components/company-info-section"
import ContactSection from "@/components/contact-section"
import Footer from "@/components/footer"
import AnimatedBackground from "@/components/animated-background"

export default function Home() {
  return (
    <div className="min-h-screen relative">
      <AnimatedBackground />
      <Navigation />
      <Hero />
      <DnaSection />
      <AboutSection />
      <ServicesSection />
      <AchievementsSection />
      <CompanyInfoSection />
      <ContactSection />
      <Footer />
    </div>
  )
}
