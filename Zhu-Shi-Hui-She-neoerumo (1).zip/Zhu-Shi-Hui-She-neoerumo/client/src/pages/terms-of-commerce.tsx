import Navigation from "@/components/navigation"
import Footer from "@/components/footer"

export default function TermsOfCommerce() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <h1 className="text-4xl font-bold mb-8 text-gray-900 dark:text-white">
            特定商取引法に基づく表記
          </h1>
          
          <div className="prose prose-lg max-w-none dark:prose-invert">
            <div className="space-y-8">
              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">販売業者</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  株式会社ネオエルモ
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">運営責任者</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  土屋 沙也加
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">所在地</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  東京都練馬区高野台（※詳細な住所は請求があり次第、遅滞なく通知いたします）
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">連絡先</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  info@neoelmo.com<br />
                  ※お問い合わせはメールにてお願いいたします。
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">URL</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  <a href="https://neoelmo.com/" className="text-blue-600 dark:text-blue-400 hover:underline">https://neoelmo.com/</a>
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">販売価格</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  「各商品・サービスごとに表示」いたします。
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">商品代金以外の必要料金</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  通信料等はお客様のご負担となります。
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">支払方法・支払時期</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  クレジットカード決済、請求書決済
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">引渡時期／提供時期</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  申込後、順次ご案内
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">返品・キャンセルについて</h2>
                <p className="text-gray-600 dark:text-gray-300">
                  サービスの性質上、返品・返金は承っておりません。<br />
                  途中解約もできかねますので、ご了承ください。
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}