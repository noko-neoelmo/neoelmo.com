import { motion } from "framer-motion"

export default function AchievementsSection() {
  return (
    <section id="achievements" className="py-24 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-gray-900 dark:text-white">
            実績
          </h2>
        </motion.div>

        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all">
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">店舗AI導入</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">チャットボット導入による顧客対応の効率化</p>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all">
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">開発効率化</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Cursor活用による開発スピード向上</p>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all">
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">業務自動化</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">GASを用いたワークフロー自動化</p>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all">
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">MA連携</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">LINE拡張ツールとMA連携による効果最大化</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
