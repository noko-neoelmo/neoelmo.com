import logoPath from "@assets/White_Holizontal.png"

export default function Footer() {
  return (
    <footer className="py-20 bg-gray-950 dark:bg-gray-100 text-white dark:text-gray-900">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-8">
              <img 
                src={logoPath} 
                alt="ネオエルモ" 
                className="h-12 w-auto transition-transform duration-300 hover:scale-105"
              />
            </div>
            
            <p className="text-xl text-gray-400 dark:text-gray-600 mb-8 font-normal leading-relaxed max-w-2xl mx-auto tracking-wide">
              新時代の事業に、新しい成長のDNAを
            </p>
          </div>
          
          <div className="border-t border-gray-800 dark:border-gray-300 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <div className="flex space-x-8">
                <a 
                  href="/privacy-policy" 
                  className="text-sm text-gray-400 dark:text-gray-600 hover:text-white dark:hover:text-gray-900 transition-all duration-300 relative group"
                >
                  <span className="relative">
                    プライバシーポリシー
                    <div className="absolute bottom-0 left-0 w-0 h-px bg-current transition-all duration-300 group-hover:w-full" />
                  </span>
                </a>
                <a 
                  href="/terms-of-commerce" 
                  className="text-sm text-gray-400 dark:text-gray-600 hover:text-white dark:hover:text-gray-900 transition-all duration-300 relative group"
                >
                  <span className="relative">
                    特定商取引法に基づく表記
                    <div className="absolute bottom-0 left-0 w-0 h-px bg-current transition-all duration-300 group-hover:w-full" />
                  </span>
                </a>
              </div>
              
              <div className="text-sm text-gray-500 dark:text-gray-700 font-medium">
                © 2025 株式会社ネオエルモ. All rights reserved.
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
