import { useState } from "react"
import { motion } from "framer-motion"
import { useTheme } from "./theme-provider"
import { useLanguage } from "@/hooks/use-language"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Moon, Sun, Menu, Globe } from "lucide-react"
import logoPath from "@assets/White_Holizontal.png"

export default function Navigation() {
  const { theme, setTheme } = useTheme()
  const { language, setLanguage, t } = useLanguage()
  const [isOpen, setIsOpen] = useState(false)

  const navItems = [
    { href: "#about", label: t("navigation.about") },
    { href: "#services", label: t("navigation.services") },
    { href: "#achievements", label: t("navigation.achievements") },
    { href: "#company", label: t("navigation.company") },
    { href: "#contact", label: t("navigation.contact") },
  ]

  const handleConsultationClick = () => {
    window.open('https://app.spirinc.com/t/AJ_mAlkX7tM_K8hOrg35d/as/S7g17bcsUAlZTWBUJJYRZ/confirm', '_blank')
  }

  const handleNavClick = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" })
    }
    setIsOpen(false)
  }

  return (
    <nav className="fixed top-0 w-full z-50 bg-gray-950/95 backdrop-blur-xl border-b border-gray-800/30">
      <div className="container mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <motion.img 
              src={logoPath} 
              alt="ネオエルモ" 
              className="h-10 w-auto"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2, ease: [0.25, 1, 0.5, 1] }}
            />
          </div>
          
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item, index) => (
              <motion.button
                key={item.href}
                onClick={() => handleNavClick(item.href)}
                className="relative group py-3 px-3 font-medium text-sm text-gray-200 hover:text-white transition-colors duration-200 ease-out-quart whitespace-nowrap"
                whileHover={{ y: -1 }}
                transition={{ duration: 0.2, ease: [0.25, 1, 0.5, 1] }}
              >
                <span className="relative z-10 tracking-wide">{item.label}</span>
                <motion.div 
                  className="absolute bottom-0 left-0 h-0.5 bg-white"
                  initial={{ width: 0 }}
                  whileHover={{ width: "100%" }}
                  transition={{ duration: 0.3, ease: [0.25, 1, 0.5, 1] }}
                />
              </motion.button>
            ))}
            <motion.div
              whileHover={{ scale: 0.98 }}
              whileTap={{ scale: 0.96 }}
              transition={{ duration: 0.15, ease: [0.25, 1, 0.5, 1] }}
            >
              <Button
                onClick={handleConsultationClick}
                className="group relative px-6 py-2.5 text-white font-medium text-sm rounded-full transition-all duration-200 ease-out-quart overflow-hidden whitespace-nowrap"
                style={{
                  backgroundColor: '#543E95'
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#6b46c1'}
                onMouseLeave={(e) => e.target.style.backgroundColor = '#543E95'}
              >
                <span className="relative z-10 flex items-center gap-2 tracking-wide">
                  {t("navigation.consultation")}
                  <motion.span
                    className="inline-block"
                    initial={{ x: 0 }}
                    whileHover={{ x: 2 }}
                    transition={{ duration: 0.2, ease: [0.25, 1, 0.5, 1] }}
                  >
                    →
                  </motion.span>
                </span>
              </Button>
            </motion.div>
            <div className="flex items-center space-x-1 ml-3 border-l border-gray-700 pl-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLanguage(language === "ja" ? "en" : "ja")}
                className="rounded-full hover:bg-gray-800 transition-all duration-200 text-gray-300 hover:text-white"
              >
                <Globe className="h-5 w-5" />
                <span className="sr-only">Toggle language</span>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                className="rounded-full hover:bg-gray-800 transition-all duration-200 text-gray-300 hover:text-white"
              >
                <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                <span className="sr-only">Toggle theme</span>
              </Button>
            </div>
          </div>

          <div className="lg:hidden flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className="rounded-full text-gray-300 hover:text-white hover:bg-gray-800"
            >
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-gray-800">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <button
                      key={item.href}
                      onClick={() => handleNavClick(item.href)}
                      className="text-left py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-800  transition-colors"
                    >
                      {item.label}
                    </button>
                  ))}
                  <Button
                    onClick={handleConsultationClick}
                    className="w-full mt-4 text-white font-medium rounded-full transition-all duration-300"
                    style={{
                      backgroundColor: '#543E95'
                    }}
                    onMouseEnter={(e) => e.target.style.backgroundColor = '#432e7a'}
                    onMouseLeave={(e) => e.target.style.backgroundColor = '#543E95'}
                  >
                    {t("navigation.consultation")}
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  )
}
