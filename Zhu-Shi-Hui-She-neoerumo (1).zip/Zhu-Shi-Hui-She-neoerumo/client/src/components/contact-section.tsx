import { motion } from "framer-motion"
import { Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ContactSection() {

  return (
    <section id="contact" className="py-32 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            className="text-center mb-20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-black mb-10 text-gray-950 dark:text-white tracking-tight font-jp">
              お問い合わせ
            </h2>
            <p className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 font-normal max-w-4xl mx-auto leading-relaxed tracking-wide">
              事業の課題やAI活用についてお気軽にご相談ください
            </p>
          </motion.div>

          <div className="flex justify-center">
            {/* Contact Form Button */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="w-full max-w-2xl"
            >
              <div className="bg-white dark:bg-gray-800 rounded-3xl p-12 text-center shadow-xl border border-gray-100 dark:border-gray-700">
                <div className="w-20 h-20 mx-auto mb-8 rounded-full flex items-center justify-center" style={{backgroundColor: '#543E95'}}>
                  <Mail className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-3xl font-bold mb-6 text-gray-950 dark:text-white tracking-tight">
                  お問い合わせはこちらから
                </h3>
                <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 leading-relaxed tracking-wide">
                  フォームに必要事項をご記入の上、お気軽にお問い合わせください。
                </p>
                <a 
                  href="https://forms.gle/UFoqGnAFVCQzFVyd6"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <motion.div
                    whileHover={{ scale: 0.98 }}
                    whileTap={{ scale: 0.96 }}
                    transition={{ duration: 0.15, ease: [0.25, 1, 0.5, 1] }}
                  >
                    <Button 
                      className="group relative w-full py-6 bg-gray-950 hover:bg-gray-900 text-white font-semibold text-lg rounded-full transition-all duration-300 ease-out-expo overflow-hidden"
                    >
                      <span className="relative z-10 flex items-center justify-center gap-3 tracking-wide">
                        お問い合わせフォームへ
                        <motion.span
                          className="inline-block"
                          initial={{ x: 0 }}
                          whileHover={{ x: 4 }}
                          transition={{ duration: 0.2, ease: [0.25, 1, 0.5, 1] }}
                        >
                          →
                        </motion.span>
                      </span>
                      <div className="absolute inset-0 bg-gradient-to-r from-brand-600 to-brand-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </Button>
                  </motion.div>
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}
