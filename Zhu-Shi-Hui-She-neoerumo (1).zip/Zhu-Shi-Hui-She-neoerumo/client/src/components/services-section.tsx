import { motion } from "framer-motion"
import { Route, Mic, Brain, Rocket, Search, MessageCircle, FileCheck, TrendingUp } from "lucide-react"
import { SiGoogle, SiLine } from "react-icons/si"

export default function ServicesSection() {
  const ownServices = [
    {
      icon: Route,
      title: "らくステップ",
      description: "LINE公式アカウントのステップ配信やトリガー配信を自然言語のみでつくることができるAIエージェント",
      tags: ["CVR向上", "自動化", "簡単設定"]
    },
    {
      icon: Mic,
      title: "VOICER",
      description: "「自分のことばを引き出す」インタビュー〜note作成までをAIエージェントがご支援",
      tags: ["パーソナルブランディング", "効率化"]
    }
  ]

  const supportServices = [
    {
      icon: Brain,
      title: "生成AI顧問",
      description: "1to1で最新のテック情報や活用方法をお伝えする伴走型コーチング"
    },
    {
      icon: Rocket,
      title: "新規事業グロース",
      description: "立ち上げからグロースまでトータルプロデュース"
    },
    {
      icon: TrendingUp,
      title: "グロースハック支援",
      description: "プロダクトマーケティングとアライアンス戦略で成長を加速"
    },
    {
      icon: SiGoogle,
      title: "Google Workspace支援",
      description: "GeminiやGASを活用したワークフロー自動化"
    },
    {
      icon: SiLine,
      title: "LINEコミュニケーション",
      description: "LINE APIを活用した顧客データ連携とパーソナライズ配信"
    }
  ]

  const tools = [
    "Google Workspace", "ChatGPT", "Claude", "Gemini", 
    "Cursor", "Dify", "LINE API", "n8n", "Perplexity"
  ]

  return (
    <section id="services" className="py-32 bg-white dark:bg-gray-950">
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center mb-24"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black mb-10 text-gray-950 dark:text-white tracking-tight font-jp">
            サービス
          </h2>
          <p className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 max-w-4xl mx-auto font-normal leading-relaxed tracking-wide">
            自社サービスから伴走支援まで、包括的なソリューションを提供
          </p>
        </motion.div>

        {/* サービス */}
        <motion.div 
          className="mb-32"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl md:text-4xl font-bold mb-16 text-center text-gray-950 dark:text-white tracking-tight">サービス</h3>
          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {ownServices.map((service, index) => (
              <motion.div
                key={service.title}
                className="group relative bg-white dark:bg-gray-900 p-12 rounded-2xl border border-gray-200/60 dark:border-gray-800/60 hover:border-gray-300 dark:hover:border-gray-700 transition-all duration-400 ease-out-expo"
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.15, ease: [0.16, 1, 0.3, 1] }}
                viewport={{ once: true }}
                whileHover={{ y: -4 }}
              >
                <div className="flex items-center mb-8">
                  <motion.div 
                    className="w-16 h-16 flex items-center justify-center mr-6 rounded-xl bg-gray-950 dark:bg-gray-100"
                    whileHover={{ scale: 1.05, rotate: 2 }}
                    transition={{ duration: 0.2, ease: [0.25, 1, 0.5, 1] }}
                  >
                    <service.icon className="text-white dark:text-gray-900 w-8 h-8" />
                  </motion.div>
                  <h4 className="text-2xl md:text-3xl font-bold text-gray-950 dark:text-white tracking-tight">{service.title}</h4>
                </div>
                <p className="text-lg text-gray-700 dark:text-gray-300 mb-8 leading-relaxed tracking-wide">
                  {service.description}
                </p>
                <div className="flex flex-wrap gap-3">
                  {service.tags.map((tag, tagIndex) => (
                    <span 
                      key={tagIndex}
                      className="text-sm px-4 py-2 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full font-medium tracking-wide"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="absolute inset-0 bg-gradient-to-br from-gray-50/0 to-gray-100/20 dark:from-gray-800/0 dark:to-gray-700/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* 支援サービス */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl md:text-4xl font-bold mb-16 text-center text-gray-950 dark:text-white tracking-tight">ご支援内容</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {supportServices.map((service, index) => (
              <motion.div
                key={service.title}
                className="group relative bg-white dark:bg-gray-900 p-8 rounded-xl border border-gray-200/60 dark:border-gray-800/60 hover:border-gray-300 dark:hover:border-gray-700 transition-all duration-300 ease-out-quart"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
                viewport={{ once: true }}
                whileHover={{ y: -2, scale: 1.02 }}
              >
                <motion.div 
                  className="w-12 h-12 bg-gray-950 dark:bg-gray-100 flex items-center justify-center mb-6 rounded-lg"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.2, ease: [0.25, 1, 0.5, 1] }}
                >
                  <service.icon className="text-white dark:text-gray-900 w-5 h-5" />
                </motion.div>
                <h4 className="text-xl font-bold mb-4 text-gray-950 dark:text-white tracking-tight">{service.title}</h4>
                <p className="text-base text-gray-700 dark:text-gray-300 leading-relaxed tracking-wide">
                  {service.description}
                </p>
                <div className="absolute inset-0 bg-gradient-to-br from-gray-50/0 to-gray-100/30 dark:from-gray-800/0 dark:to-gray-700/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* 対応ツール */}
        <motion.div 
          className="mt-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-xl md:text-2xl font-bold mb-8 text-center text-gray-900 dark:text-white">対応可能ツール</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {tools.map((tool, index) => (
              <motion.span
                key={tool}
                className="px-4 py-2 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-sm font-medium border border-gray-200 dark:border-gray-700"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                viewport={{ once: true }}
              >
                {tool}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
