import { motion } from "framer-motion"

export default function DnaSection() {
  return (
    <section className="py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-gray-900 dark:text-white">
            新時代の事業に、新しい成長のDNAを
          </h2>
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto font-light">
            事業設計からAI導入、顧客接点のデザインまで「事業のコア」を共創します。
          </p>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          {/* Philosophy Section */}
          <motion.div
            className="mb-16 text-center max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
              <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                <span className="font-bold text-gray-900 dark:text-white">事業を伸ばす魔法のプロンプトは存在しません。</span>
              </p>
              <p className="text-base md:text-lg text-gray-600 dark:text-gray-400 leading-relaxed mb-4">
                高速で変化する世の中で、強い事業を育てるためにはAIの活用が不可欠です。<br />
                しかし、ただ導入すればうまくいくわけではありません。
              </p>
              <p className="text-base md:text-lg text-gray-600 dark:text-gray-400 leading-relaxed mb-8">
                体に異物が入ればアレルギーが出るように、<br />
                ヒトも、企業文化もアップデートすることが重要です。
              </p>
              <p className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white">
                ネオエルモが作るのは、新しい成長のDNA.
              </p>
          </motion.div>

          {/* DNA Venn Diagram */}
          <motion.div
            className="relative flex justify-center mb-16"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <div className="relative w-96 h-96 mx-auto">
              {/* Design Circle - Top */}
              <motion.div
                className="absolute w-52 h-52 rounded-full border-2 border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 flex items-center justify-center shadow-lg"
                style={{ top: "0px", left: "88px", zIndex: 3 }}
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                viewport={{ once: true }}
              >
                <div className="text-center relative z-10">
                  <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">Design</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 leading-tight">強くしなやかな<br />事業設計</p>
                </div>
              </motion.div>

              {/* Narrative Circle - Bottom Left */}
              <motion.div
                className="absolute w-52 h-52 rounded-full border-2 flex items-center justify-center shadow-lg"
                style={{ 
                  top: "144px", 
                  left: "0px", 
                  zIndex: 2,
                  borderColor: '#543E95',
                  background: 'linear-gradient(135deg, #f3f0ff 0%, #e9e5ff 100%)'
                }}
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                viewport={{ once: true }}
              >
                <div className="text-center relative z-10">
                  <h3 className="text-xl font-bold mb-2" style={{color: '#543E95'}}>Narrative</h3>
                  <p className="text-sm leading-tight" style={{color: '#543E95'}}>コミュニティに<br />支持される<br />マーケティング</p>
                </div>
              </motion.div>

              {/* AI Circle - Bottom Right */}
              <motion.div
                className="absolute w-52 h-52 rounded-full border-2 border-blue-500 dark:border-blue-400 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 flex items-center justify-center shadow-lg"
                style={{ top: "144px", left: "176px", zIndex: 1 }}
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                transition={{ duration: 0.8, delay: 1.0 }}
                viewport={{ once: true }}
              >
                <div className="text-center relative z-10">
                  <h3 className="text-xl font-bold mb-2 text-blue-600 dark:text-blue-400">AI</h3>
                  <p className="text-sm text-blue-600 dark:text-blue-400 leading-tight">成果を生み出す<br />AI活用</p>
                </div>
              </motion.div>
            </div>
          </motion.div>



          {/* Bottom Message */}
          <motion.div
            className="text-center max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.6 }}
            viewport={{ once: true }}
          >
              <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                磨き抜かれた戦略があってこそ、どこに、どんなAIを導入すべきかが見えてきます。
              </p>
              <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                私たちは、事業設計からAI開発、そしてAIで結果を出す強固な組織文化まで、一気通貫でプロデュース。
              </p>
              <p className="text-xl md:text-2xl font-bold" style={{color: '#543E95'}}>
                目まぐるしく風向きが変わるビジネスの海で、共に灯台を目指すパートナーです。
              </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
